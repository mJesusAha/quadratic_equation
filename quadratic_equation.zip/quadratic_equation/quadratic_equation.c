
#include "quadratic_equation.h"

roots solve_equation(long double a, long double b, long double c) {
  roots n = {0};
  /*Eсли уравнение линейное*/
  if (a == 0 && b != 0) {
    n.x1 = ((0 - c) / b);
    n.root = 1;
    /*Eсли уравнение квадратное*/
  } else if (a != 0) {
    n.root = 2;
    double D = (b * b) - (4 * a * c);
    double sqrt_d = sqrt(fabs(D));
    /*Eсли уравнение имеет 1 корень*/
    if (D == 0.0) {
      n.x1 = n.x2 = -b / (2 * a);
      /*Eсли уравнение имеет 2 действительных корня*/
    } else if (D > 0) {
      n.x1 = (-b + sqrt_d) / (2 * a);
      n.x2 = (-b - sqrt_d) / (2 * a);
      /*Eсли уравнение имеет 2 комплексных корня*/
    } else if (D < 0) {
      n.x1 = n.x2 = -b / (2 * a);
      n.x1i = sqrt_d / (2 * a);
      n.x2i = (-1 * sqrt_d) / (2 * a);
    }
  }
  return n;
}
