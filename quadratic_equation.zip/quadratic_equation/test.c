#include <check.h>

#include "quadratic_equation.h"

START_TEST(equation_0_0_0) {
  roots n = {0};
  n = solve_equation(0, 0, 0);
  ck_assert_int_eq(n.root, 0);
  ck_assert_double_eq(n.x1, 0);
  ck_assert_double_eq(n.x2, 0);
  ck_assert_double_eq(n.x1i, 0);
  ck_assert_double_eq(n.x2i, 0);
}
END_TEST

START_TEST(equation_0_1_1) {
  roots n = {0};
  n = solve_equation(0, 1, 1);
  ck_assert_int_eq(n.root, 1);
  ck_assert_double_eq(n.x1, -1);
  ck_assert_double_eq(n.x2, 0);
  ck_assert_double_eq(n.x1i, 0);
  ck_assert_double_eq(n.x2i, 0);
}
END_TEST
START_TEST(equation_m3_0_75) {
  roots n = {0};
  n = solve_equation(-3, 0, 75);
  ck_assert_int_eq(n.root, 2);
  ck_assert_double_eq(n.x1, -5);
  ck_assert_double_eq(n.x2, 5);
  ck_assert_double_eq(n.x1i, 0);
  ck_assert_double_eq(n.x2i, 0);
}
END_TEST

START_TEST(equation_1_m12_36) {
  roots n = {0};
  n = solve_equation(1, -12, 36);
  ck_assert_int_eq(n.root, 2);
  ck_assert_double_eq(n.x1, 6);
  ck_assert_double_eq(n.x2, 6);
  ck_assert_double_eq(n.x1i, 0);
  ck_assert_double_eq(n.x2i, 0);
}
END_TEST

START_TEST(equation_4_32_64) {
  roots n = {0};
  n = solve_equation(4, 32, 64);
  ck_assert_int_eq(n.root, 2);
  ck_assert_double_eq(n.x1, -4);
  ck_assert_double_eq(n.x2, -4);
  ck_assert_double_eq(n.x1i, 0);
  ck_assert_double_eq(n.x2i, 0);
}
END_TEST

START_TEST(equation_1_10_m39) {
  roots n = {0};
  n = solve_equation(1, 10, -39);
  ck_assert_int_eq(n.root, 2);
  ck_assert_double_eq(n.x1, 3);
  ck_assert_double_eq(n.x2, -13);
  ck_assert_double_eq(n.x1i, 0);
  ck_assert_double_eq(n.x2i, 0);
}
END_TEST

START_TEST(equation_4_28_m735) {
  roots n = {0};
  n = solve_equation(4, 28, -735);
  ck_assert_int_eq(n.root, 2);
  ck_assert_double_eq(n.x1, 10.5);
  ck_assert_double_eq(n.x2, -17.5);
  ck_assert_double_eq(n.x1i, 0);
  ck_assert_double_eq(n.x2i, 0);
}
END_TEST

START_TEST(equation_5_6_5) {
  roots n = {0};
  n = solve_equation(5, 6, 5);
  ck_assert_int_eq(n.root, 2);
  ck_assert_double_eq(n.x1, -0.6);
  ck_assert_double_eq(n.x2, -0.6);
  ck_assert_double_eq(n.x1i, 0.8);
  ck_assert_double_eq(n.x2i, -0.8);
}
END_TEST

START_TEST(equation_1_m3_8p5) {
  roots n = {0};
  n = solve_equation(1, -3, 8.5);
  ck_assert_int_eq(n.root, 2);
  ck_assert_double_eq(n.x1, 1.5);
  ck_assert_double_eq(n.x2, 1.5);
  ck_assert_double_eq(n.x1i, 2.5);
  ck_assert_double_eq(n.x2i, -2.5);
}
END_TEST

Suite *suite_insert(void) {
  Suite *s = suite_create("tests_queric_equation");
  TCase *tc = tcase_create("test:");

  tcase_add_test(tc, equation_0_1_1);
  tcase_add_test(tc, equation_0_0_0);
  tcase_add_test(tc, equation_m3_0_75);
  tcase_add_test(tc, equation_1_m12_36);
  tcase_add_test(tc, equation_4_32_64);
  tcase_add_test(tc, equation_1_10_m39);
  tcase_add_test(tc, equation_4_28_m735);
  tcase_add_test(tc, equation_5_6_5);
  tcase_add_test(tc, equation_1_m3_8p5);
  suite_add_tcase(s, tc);
  return s;
}
int main(void) {
  int number_failed;
  Suite *s1;
  SRunner *sr;
  s1 = suite_insert();
  sr = srunner_create(s1);

  srunner_run_all(sr, CK_NORMAL);
  srunner_set_fork_status(sr, CK_NOFORK);

  number_failed = srunner_ntests_failed(sr);
  srunner_free(sr);
  return number_failed == 0 ? 0 : 1;
}